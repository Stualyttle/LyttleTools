export declare const update: () => void;
