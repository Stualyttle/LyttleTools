export const getNodeVersion = () => {
  return process.version ?? "unknown";
};
