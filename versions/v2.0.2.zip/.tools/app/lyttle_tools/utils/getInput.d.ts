export declare const getInput: (question: any) => Promise<string>;
