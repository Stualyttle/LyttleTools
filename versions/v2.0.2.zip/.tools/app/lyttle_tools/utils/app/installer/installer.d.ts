import { Config } from "../../config/getConfig";
export declare const installer: (config: Config) => Promise<never>;
