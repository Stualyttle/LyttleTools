export declare const runCommand: (command: any) => any;
