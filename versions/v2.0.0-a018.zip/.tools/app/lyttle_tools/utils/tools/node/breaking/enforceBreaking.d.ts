export declare const breaking: () => Promise<void>;
