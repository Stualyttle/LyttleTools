export declare const yesAndNo: string;
