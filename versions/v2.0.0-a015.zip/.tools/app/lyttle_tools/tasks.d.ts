export declare const tasks: () => Promise<void>;
