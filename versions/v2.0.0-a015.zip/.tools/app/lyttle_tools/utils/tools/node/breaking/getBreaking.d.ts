export declare const getBreaking: () => any[];
