export declare const welcome: () => void;
