export declare const config: {
    app: {
        version: number[];
        debug: boolean;
        path: string;
        runningOnWindows: boolean;
        isGitHook: boolean;
        gitMessage: string;
    };
    settings: {};
};
