export declare const getNodeVersion: () => string;
