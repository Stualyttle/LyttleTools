"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.yesAndNo = void 0;
exports.yesAndNo = "\x1b[0m" +
    "(" +
    "\x1b[32m" +
    "y" +
    "\x1b[0m" +
    "/" +
    "\x1b[31m" +
    "n" +
    "\x1b[0m" +
    ")";
//# sourceMappingURL=text.js.map