export declare const getYamlConfig: (path: any) => {};
