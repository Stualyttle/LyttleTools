export declare const set: ([lastVersion, myVersion]: [any, any]) => any[];
