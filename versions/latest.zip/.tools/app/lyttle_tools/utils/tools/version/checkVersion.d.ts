declare type version = [number, number, number, number];
export declare const check: () => [version, version] | null;
export {};
