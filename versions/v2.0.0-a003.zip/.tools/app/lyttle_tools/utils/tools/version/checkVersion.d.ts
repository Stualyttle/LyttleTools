export declare type Version = [number, number, number, number];
export declare type Versions = [Version, Version];
export declare const check: () => Versions;
