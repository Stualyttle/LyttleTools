export declare const tasks: () => void;
