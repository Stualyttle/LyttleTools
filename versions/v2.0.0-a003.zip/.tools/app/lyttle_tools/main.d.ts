export declare const config: {
    isGitHook: boolean;
    path: string;
    isWindows: boolean;
    config: {};
};
