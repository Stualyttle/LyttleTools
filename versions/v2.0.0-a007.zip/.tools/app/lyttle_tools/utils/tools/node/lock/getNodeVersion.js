"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getNodeVersion = void 0;
const getNodeVersion = () => {
    return process.version ?? "unknown";
};
exports.getNodeVersion = getNodeVersion;
//# sourceMappingURL=getNodeVersion.js.map