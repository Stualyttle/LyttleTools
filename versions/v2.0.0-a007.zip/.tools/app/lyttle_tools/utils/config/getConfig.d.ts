export declare const getConfig: () => {
    app: {
        isGitHook: boolean;
        runningOnWindows: boolean;
        path: string;
        version: number[];
    };
    settings: {};
};
