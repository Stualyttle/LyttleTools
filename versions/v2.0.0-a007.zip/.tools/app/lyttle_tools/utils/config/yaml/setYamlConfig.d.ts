export declare const setYamlConfig: (config: any, path: any) => void;
