export declare const config: {
    app: {
        isGitHook: boolean;
        runningOnWindows: boolean;
        path: string;
        version: number[];
    };
    settings: {};
};
