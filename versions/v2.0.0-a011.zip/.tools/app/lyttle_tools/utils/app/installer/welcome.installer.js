"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.welcome = void 0;
const welcome = () => {
    console.log(`\nWelcome to Lyttle Tools!\n\n` +
        `This is a tool to help you manage your projects.\n` +
        `Lets go thru the installation config together!\n`);
};
exports.welcome = welcome;
//# sourceMappingURL=welcome.installer.js.map