export declare const checkBranch: () => Promise<void>;
