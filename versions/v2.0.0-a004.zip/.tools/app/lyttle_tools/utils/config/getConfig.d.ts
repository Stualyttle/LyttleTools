export declare const getConfig: () => {
    isGitHook: boolean;
    path: string;
    isWindows: boolean;
    config: {};
};
