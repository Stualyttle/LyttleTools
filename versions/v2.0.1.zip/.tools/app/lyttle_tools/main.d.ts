export declare const config: import("./utils/config/getConfig").Config;
