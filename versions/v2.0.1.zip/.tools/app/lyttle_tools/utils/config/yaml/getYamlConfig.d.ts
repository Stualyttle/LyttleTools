import { ConfigSettings } from "./setYamlConfig";
export declare const getYamlConfig: (path: string) => ConfigSettings;
