export declare const lock: () => void;
