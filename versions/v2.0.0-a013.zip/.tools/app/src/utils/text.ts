export const yesAndNo =
  "\x1b[0m" +
  "(" +
  "\x1b[32m" +
  "y" +
  "\x1b[0m" +
  "/" +
  "\x1b[31m" +
  "n" +
  "\x1b[0m" +
  ")";
