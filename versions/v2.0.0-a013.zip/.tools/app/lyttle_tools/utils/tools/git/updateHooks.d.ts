export declare const updateHooks: () => void;
