export declare const installer: (config: any) => Promise<never>;
