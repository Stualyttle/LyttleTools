export declare const ask: (question?: string | null, info?: string | null, warn?: string | null, extra?: string | null) => Promise<unknown>;
