export declare const pull: () => void;
