export declare const check: () => Promise<unknown>;
